#!/bin/sh
java -jar /usr/lib/plptool5/PLPToolStatic.jar -W -D ./extensions $@
